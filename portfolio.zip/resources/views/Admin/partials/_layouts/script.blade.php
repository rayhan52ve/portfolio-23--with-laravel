<!-- Vendor Scripts Start -->
<script src="{{asset('backend/js/vendor/jquery-3.5.1.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/OverlayScrollbars.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/autoComplete.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/clamp.min.js')}}"></script>
    <script src="{{asset('backend/icon/acorn-icons.js')}}"></script>
    <script src="{{asset('backend/icon/acorn-icons-interface.js')}}"></script>
    <script src="{{asset('backend/icon/acorn-icons-commerce.js')}}"></script>

    <script src="{{asset('backend/js/vendor/Chart.bundle.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/chartjs-plugin-rounded-bar.min.js')}}"></script>
    <script src="{{asset('backend/js/vendor/jquery.barrating.min.js')}}"></script>

    <!-- Vendor Scripts End -->

    <!-- Template Base Scripts Start -->
    <script src="{{asset('backend/js/base/helpers.js')}}"></script>
    <script src="{{asset('backend/js/base/globals.js')}}"></script>
    <script src="{{asset('backend/js/base/nav.js')}}"></script>
    <script src="{{asset('backend/js/base/search.js')}}"></script>
    <script src="{{asset('backend/js/base/settings.js')}}"></script>
    <!-- Template Base Scripts End -->
    <!-- Page Specific Scripts Start -->

    <script src="{{asset('backend/js/cs/charts.extend.js')}}"></script>
    <script src="{{asset('backend/js/pages/dashboard.js')}}"></script>
    <script src="{{asset('backend/js/common.js')}}"></script>
    <script src="{{asset('backend/js/scripts.js')}}"></script>
    <script src="{{asset('backend/js/base/loader.js')}}"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/js/all.min.js"></script> --}}