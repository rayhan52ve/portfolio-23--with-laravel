<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Portfolio-MD.Sajid Rayhan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    @include('Frontend.partials._layouts.css')


</head>

@yield('content')

</html>
